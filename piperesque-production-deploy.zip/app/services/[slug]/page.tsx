import { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";

import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  ChevronRight,
  MapPin,
  Phone,
  ShieldCheck,
  Sparkles,
  Wrench,
} from "lucide-react";

import FAQSchema from "@/components/seo/faq-schema";
import BreadcrumbSchema from "@/components/seo/breadcrumb-schema";
import JsonLd from "@/components/seo/json-ld";

import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import CTA from "@/components/sections/cta";
import ReferralLeadForm from "@/components/contact/referral-lead-form";

import { services } from "@/lib/data/services";
import { siteConfig } from "@/lib/config/site";

type Props = {
  params: Promise<{
    slug: string;
  }>;
};

type ServiceContent = {
  heroBadge: string;
  intro: string[];
  warningSigns: string[];
  repairProcess: string[];
  pricing: {
    label: string;
    value: string;
  }[];
  faqs: {
    question: string;
    answer: string;
  }[];
  overview: string;
};

const serviceContent: Record<string, ServiceContent> = {
  "emergency-plumbing": {
    heroBadge: "Emergency plumbing information",
    intro: [
      "A plumbing emergency can cause significant water damage when it is not addressed quickly. Burst pipes, severe leaks, sewer backups, and major water heater failures can affect walls, floors, cabinets, and other parts of a property.",
      "PipeResque helps visitors find plumbing service options and information. If a plumbing problem is actively causing damage, shutting off the water when safe and contacting an appropriate local plumbing professional can help limit further damage.",
      "The right response depends on the type of plumbing failure, the location of the problem, accessibility, and the condition of the plumbing system. A professional assessment can determine the appropriate repair approach."
    ],
    warningSigns: [
      "Water is actively leaking from a pipe, wall, ceiling, or fixture.",
      "Water or sewage is backing up into tubs, toilets, or floor drains.",
      "Multiple plumbing fixtures stop draining normally at the same time.",
      "A sudden unexplained loss of water pressure occurs.",
      "You hear unusual rushing or banging sounds from the plumbing system."
    ],
    repairProcess: [
      "Assess the plumbing problem and identify the affected area.",
      "If necessary and safe, isolate the water supply to limit additional damage.",
      "Inspect the affected plumbing system and determine the likely cause.",
      "Repair or replace the damaged component using an appropriate repair method.",
      "Test the plumbing system and explain any recommended follow-up work."
    ],
    pricing: [
      { label: "Diagnostic service", value: "Varies by provider and scope" },
      { label: "Burst pipe repair", value: "Varies by damage and access" },
      { label: "Main line repair", value: "Varies by pipe condition and location" },
      { label: "Sewer backup service", value: "Varies by blockage and repair requirements" },
      { label: "Water heater repair", value: "Varies by unit and failed component" }
    ],
    faqs: [
      {
        question: "What counts as a plumbing emergency?",
        answer:
          "Active leaks, burst pipes, sewage backups, flooding, and major plumbing failures that can cause property damage are commonly treated as urgent plumbing problems."
      },
      {
        question: "What should I do during a major plumbing leak?",
        answer:
          "If it is safe, shut off the affected water supply or main water valve and move belongings away from the affected area. Contact a qualified local plumbing professional for an assessment."
      },
      {
        question: "Do emergency plumbing services cost more?",
        answer:
          "Pricing depends on the provider, time of service, repair type, labor, parts, accessibility, and the extent of the plumbing problem."
      },
      {
        question: "Can a burst pipe be repaired the same day?",
        answer:
          "Some accessible burst pipe repairs can be completed during the initial service visit. More complex repairs may require additional work or parts."
      },
      {
        question: "What should I do if sewage is backing up?",
        answer:
          "Avoid using affected plumbing fixtures and contact a plumbing professional promptly. Sewage backups can create sanitation and property-damage concerns."
      }
    ],
    overview:
      "Emergency plumbing problems require timely assessment because active water leaks and sewage backups can cause additional property damage. The appropriate repair depends on the specific plumbing failure."
  },

  "sewer-line-repair": {
    heroBadge: "Sewer line repair information",
    intro: [
      "Sewer line problems can affect multiple plumbing fixtures at the same time. Cracked pipes, tree root intrusion, ground shifting in Houston's expansive clay soil, and collapsed vintage cast iron lines can cause sluggish drainage, foul odors, and severe wastewater backups.",
      "A proper sewer line evaluation begins with a high-definition video camera inspection. This allows an independent technician to pinpoint whether the issue is a simple paper blockage, grease accumulation, root invasion at pipe joints, or a structural pipe belly or collapse.",
      "Repair solutions vary based on pipe depth, location beneath slabs or landscaping, accessibility, and severity of damage. Some situations require localized spot repair or trenchless pipe relining, while others call for conventional line excavation and replacement."
    ],
    warningSigns: [
      "Multiple plumbing fixtures gurgling or draining slowly at the same time.",
      "Wastewater or toilet sewage backing up into lowest-level bathtubs or shower stalls.",
      "Persistent sulfur or sewage odors inside the home or near the exterior foundation.",
      "Unexplained lush, overly green, or soggy patches in the yard above the sewer lateral.",
      "Frequent or recurring toilet clogs that standard plunging fails to resolve.",
      "Gurgling sounds from the bathroom sink when the toilet is flushed."
    ],
    repairProcess: [
      "Immediate system shutoff and cleanout cap inspection to relieve line pressure.",
      "Sewer camera diagnostic inspection through accessible ground-level cleanouts.",
      "Evaluation of pipe condition: identification of cracks, joint separation, or tree roots.",
      "Discussion of options: mechanical snaking, hydro-jetting, trenchless relining, or spot excavation.",
      "Execution of repair using durable, code-compliant PVC or HDPE piping.",
      "Post-repair camera verification to ensure unobstructed flow to the municipal sewer or septic system."
    ],
    pricing: [
      { label: "Sewer camera inspection", value: "Determined directly by provider" },
      { label: "High-pressure hydro jetting", value: "Varies by line length and blockage" },
      { label: "Trenchless pipe relining (CIPP)", value: "Varies by pipe diameter and run" },
      { label: "Localized spot repair", value: "Varies by depth and surface access" },
      { label: "Complete sewer line replacement", value: "Varies by distance to city main" }
    ],
    faqs: [
      {
        question: "What should homeowners avoid doing during an active sewer backup?",
        answer:
          "Immediately stop running water, including washing machines, dishwashers, sinks, and showers. Do not pour caustic chemical drain cleaners into a completely blocked sewer line, as corrosive chemicals will sit in the pipes and present safety risks to servicing technicians."
      },
      {
        question: "Why are sewer line problems so common in Greater Houston?",
        answer:
          "Houston's subsoil consists primarily of expansive gumbo clay that swells significantly during wet periods and shrinks during summer droughts. This continuous ground movement places immense shear stress on underground sewer lines, leading to cracked joints, bellies, and root penetration from mature live oaks and pine trees."
      },
      {
        question: "Can a sewer line be repaired without digging up my yard or driveway?",
        answer:
          "In many cases, yes. Trenchless technologies such as cured-in-place pipe (CIPP) lining or pipe bursting allow technicians to rehabilitate damaged sewer lines through small access pits without digging continuous trenches through landscaping, driveways, or patios. Suitability depends on pipe structural integrity."
      },
      {
        question: "What questions should I ask an independent plumbing contractor before sewer work?",
        answer:
          "Ask whether the technician will perform a video camera inspection before and after work, whether they offer trenchless alternatives, what city permits are required, whether cleanouts will be installed, and what warranty terms apply to materials and labor."
      },
      {
        question: "Will insurance cover sewer line repair in Texas?",
        answer:
          "Standard homeowners insurance policies typically exclude wear-and-tear or root intrusion on exterior sewer laterals unless an optional sewer/water line endorsement or utility line coverage was added to the policy. Check with your insurance carrier regarding your specific policy riders."
      }
    ],
    overview:
      "Sewer line problems can disrupt household sanitation and threaten property foundations. Accurate camera diagnosis helps determine whether hydro-jetting, trenchless pipe relining, or conventional pipe replacement is appropriate for your home."
  },

  "drain-cleaning": {
    heroBadge: "Drain cleaning information",
    intro: [
      "Slow or blocked drains are common plumbing problems. Grease, hair, soap residue, mineral buildup, and other debris can restrict water flow through sinks, showers, tubs, and drain lines.",
      "A recurring clog can sometimes indicate a deeper problem in a branch line or main sewer line. The appropriate cleaning method depends on the location and type of obstruction.",
      "Professional drain cleaning may involve mechanical tools, specialized equipment, or inspection methods when a recurring blockage requires additional diagnosis."
    ],
    warningSigns: [
      "Water drains noticeably slower than normal.",
      "A sink, shower, or tub repeatedly becomes blocked.",
      "An unpleasant odor comes from a drain.",
      "Water backs up when another fixture is used.",
      "Several fixtures begin draining slowly at the same time."
    ],
    repairProcess: [
      "Identify the affected fixture and determine whether the blockage appears localized.",
      "Use an appropriate mechanical or professional drain-cleaning method.",
      "Investigate recurring or difficult blockages for a deeper plumbing issue.",
      "Confirm that water flow has returned to normal.",
      "Provide recommendations for reducing future buildup when appropriate."
    ],
    pricing: [
      { label: "Basic drain cleaning", value: "Varies by provider and blockage" },
      { label: "Drain snaking", value: "Varies by equipment and scope" },
      { label: "Hydro-jetting", value: "Varies by line and buildup" },
      { label: "Main drain clearing", value: "Varies by blockage location" },
      { label: "Emergency drain service", value: "Varies by provider and timing" }
    ],
    faqs: [
      {
        question: "When should I call for drain cleaning?",
        answer:
          "Repeated slow drainage, recurring clogs, multiple affected fixtures, or water backing up through another fixture are good reasons to request a professional assessment."
      },
      {
        question: "What is hydro-jetting?",
        answer:
          "Hydro-jetting uses pressurized water to remove certain types of buildup and debris from plumbing lines. A professional should determine whether it is suitable for the pipe."
      },
      {
        question: "Can a drain clog indicate a sewer problem?",
        answer:
          "Yes. Multiple fixtures backing up together can indicate a blockage or structural issue farther down the drainage system."
      },
      {
        question: "Should I use chemical drain cleaners?",
        answer:
          "Chemical drain cleaners may not address the underlying cause of recurring blockages. A plumbing professional can determine a suitable cleaning method."
      },
      {
        question: "How can I reduce drain clogs?",
        answer:
          "Using appropriate drain strainers, avoiding grease disposal through sinks, and addressing recurring slow drainage early can help reduce plumbing problems."
      }
    ],
    overview:
      "Drain cleaning restores water flow and can help identify recurring plumbing problems before they become more serious."
  },
    "leak-detection": {
    heroBadge: "Leak detection information",
    intro: [
      "Hidden plumbing leaks can occur behind walls, beneath floors, under cabinets, around fixtures, or near water heaters. If left unresolved, even a small leak can contribute to water waste and property damage.",
      "Leak detection focuses on identifying the likely source of unexplained water loss or moisture. Depending on the situation, a plumbing professional may use visual inspection, pressure testing, acoustic equipment, thermal imaging, or other diagnostic methods.",
      "The appropriate repair depends on the location and cause of the leak. A targeted diagnosis can help determine whether the problem involves a fitting, fixture, supply line, drain line, or another part of the plumbing system."
    ],
    warningSigns: [
      "Your water usage increases without an obvious change in household activity.",
      "You notice unexplained dampness, staining, or discoloration.",
      "Water appears around cabinets, fixtures, walls, or floors.",
      "You hear water running when plumbing fixtures are not being used.",
      "A musty odor develops near an area where moisture may be present."
    ],
    repairProcess: [
      "Review the visible symptoms and identify possible areas of water loss.",
      "Inspect accessible plumbing fixtures, valves, and connections.",
      "Use appropriate diagnostic equipment when the leak is not visibly accessible.",
      "Identify the likely source and determine an appropriate repair method.",
      "Repair the affected component and test the plumbing system afterward."
    ],
    pricing: [
      { label: "Leak inspection", value: "Varies by provider and scope" },
      { label: "Hidden leak detection", value: "Varies by diagnostic requirements" },
      { label: "Slab leak diagnosis", value: "Varies by property and access" },
      { label: "Localized leak repair", value: "Varies by pipe and location" },
      { label: "Pipe replacement or rerouting", value: "Varies by repair requirements" }
    ],
    faqs: [
      {
        question: "How can I tell if I have a hidden plumbing leak?",
        answer:
          "Unexplained water usage, damp areas, staining, musty odors, or sounds of running water when fixtures are off can indicate a hidden leak."
      },
      {
        question: "How are hidden leaks detected?",
        answer:
          "Depending on the situation, professionals may use visual inspection, pressure testing, acoustic equipment, thermal imaging, or other diagnostic methods."
      },
      {
        question: "Can a leak damage my home?",
        answer:
          "Yes. An unresolved plumbing leak can contribute to water damage and deterioration of affected building materials."
      },
      {
        question: "Does every hidden leak require opening a wall?",
        answer:
          "Not necessarily. Diagnostic methods may help narrow down the source before invasive access is considered."
      },
      {
        question: "What should I do if I suspect a major leak?",
        answer:
          "If safe, reduce or shut off the water supply to the affected area and contact a plumbing professional for an assessment."
      }
    ],
    overview:
      "Accurate leak detection helps identify unexplained water loss and hidden plumbing problems so that an appropriate repair can be planned."
  },

  "water-heater-repair": {
    heroBadge: "Water heater information",
    intro: [
      "A water heater problem can affect showers, cleaning, laundry, and other daily activities. Common symptoms include inconsistent hot water, unusual noises, visible leaks, or a unit that no longer heats water properly.",
      "A water heater should be diagnosed before deciding whether repair or replacement is appropriate. The problem may involve a heating component, thermostat, connection, valve, sediment buildup, or another part of the system.",
      "The best repair or replacement option depends on the equipment type, age, condition, household demand, installation requirements, and the specific failure."
    ],
    warningSigns: [
      "Hot water runs out unusually quickly.",
      "The water temperature is inconsistent.",
      "Water is leaking around the water heater.",
      "The unit produces unusual rumbling, popping, or banging sounds.",
      "Hot water appears discolored or rusty."
    ],
    repairProcess: [
      "Inspect the water heater and identify the reported symptoms.",
      "Determine whether the problem involves a component, connection, valve, or tank.",
      "Evaluate whether repair is appropriate based on the unit's condition.",
      "Repair the affected component or discuss replacement when necessary.",
      "Test the system and verify that it is operating correctly."
    ],
    pricing: [
      { label: "Water heater diagnosis", value: "Varies by provider and scope" },
      { label: "Component repair", value: "Varies by failed component" },
      { label: "Water heater maintenance", value: "Varies by system and service" },
      { label: "Tank replacement", value: "Varies by model and installation" },
      { label: "Tankless replacement", value: "Varies by system and installation" }
    ],
    faqs: [
      {
        question: "Should I repair or replace my water heater?",
        answer:
          "The decision depends on the unit's age, condition, repair requirements, performance, and replacement cost. A professional diagnosis can help determine the appropriate option."
      },
      {
        question: "What are common water heater problems?",
        answer:
          "Common symptoms include insufficient hot water, inconsistent temperature, leaks, unusual noises, and component failures."
      },
      {
        question: "How long does a water heater last?",
        answer:
          "Service life varies depending on the equipment type, installation, water conditions, usage, and maintenance."
      },
      {
        question: "Is a leaking water heater urgent?",
        answer:
          "An active leak should be addressed promptly because continued water leakage can cause property damage."
      },
      {
        question: "Can sediment affect a water heater?",
        answer:
          "Sediment buildup can affect water heater performance and may contribute to noise and reduced efficiency."
      }
    ],
    overview:
      "Water heater diagnosis helps determine whether a failing system needs a component repair, maintenance, or replacement."
  },

  "pipe-repair": {
    heroBadge: "Pipe repair information",
    intro: [
      "A burst or severely damaged pipe can release a large amount of water into a property. Water may enter walls, ceilings, cabinets, floors, or other areas and can cause additional damage if the flow is not controlled.",
      "If a pipe is actively leaking, shutting off the water supply when it is safe to do so can help limit additional water loss. The next step is identifying the failed section and determining the appropriate repair.",
      "The repair can range from replacing a localized section of pipe to addressing a larger plumbing-system problem. The correct solution depends on the pipe material, location, accessibility, and condition of nearby plumbing."
    ],
    warningSigns: [
      "A pipe is visibly cracked or leaking.",
      "Water suddenly appears from a wall, ceiling, cabinet, or floor.",
      "There is a sudden and unexplained loss of water pressure.",
      "You hear continuous rushing water when fixtures are not being used.",
      "The water meter indicates ongoing water use when the property is not using water."
    ],
    repairProcess: [
      "Shut off the affected water supply when safe to do so.",
      "Locate the failed pipe section and assess surrounding plumbing.",
      "Determine whether the failure is localized or part of a larger plumbing issue.",
      "Repair or replace the affected section using an appropriate method.",
      "Restore water service and test the repaired plumbing system."
    ],
    pricing: [
      { label: "Pipe inspection & diagnosis", value: "Varies by provider and access" },
      { label: "Localized pipe repair", value: "Varies by pipe and damage" },
      { label: "Pipe section replacement", value: "Varies by material and location" },
      { label: "Main line repair", value: "Varies by system and access" },
      { label: "Additional water-damage work", value: "Handled separately based on damage" }
    ],
    faqs: [
      {
        question: "What should I do if a water pipe begins leaking or bursts?",
        answer:
          "If it is safe, shut off the main or fixture water supply valve, move furniture away from standing water, and contact a plumbing professional promptly."
      },
      {
        question: "Can a leaking pipe be repaired without replacing the whole line?",
        answer:
          "Depending on the location, age, and condition of the piping, a localized section replacement or coupling repair is often possible."
      },
      {
        question: "What causes residential pipes to fail?",
        answer:
          "Pipe failures can result from age, shifting soil, high water pressure, corrosion, freezing temperatures, or wear on fittings."
      }
    ],
    overview:
      "Pipe repair requires prompt attention to prevent structural moisture damage. Fast isolation and accurate diagnosis help determine the appropriate repair approach."
  },

  "toilet-repair": {
    heroBadge: "Toilet repair information",
    intro: [
      "Toilet malfunctions can disrupt an entire household. Common issues range from simple flapper leaks and running water to severe clogs, bowl cracks, and recurring backups.",
      "Prompt inspection of toilet leaks is crucial to prevent water damage to subflooring and ceilings below. A professional plumber can determine whether a rebuild, unclogging, or complete fixture replacement is needed.",
      "PipeResque connects Houston homeowners with independent plumbing specialists who inspect, rebuild, or install residential toilets quickly."
    ],
    warningSigns: [
      "Toilet continues running long after flushing.",
      "Water pools around the base or toilet bolts on the bathroom floor.",
      "Weak, incomplete, or phantom flushing occurs.",
      "Frequent clogs require repeated plunging.",
      "Gurgling sounds come from the toilet when sinks or tubs drain."
    ],
    repairProcess: [
      "Inspect the tank internals, flapper, fill valve, and flush mechanism.",
      "Check wax ring seal and toilet flange connection for water leaks.",
      "Clear any downstream drain blockages using an auger if needed.",
      "Replace worn components or reset fixture on a new wax seal.",
      "Test flush volume, bowl fill, and water shutoff."
    ],
    pricing: [
      { label: "Toilet diagnosis & clearing", value: "Determined directly by provider" },
      { label: "Component rebuild (valve/flapper)", value: "Varies by parts and fixture" },
      { label: "Wax ring reset & reseal", value: "Varies by subfloor condition" },
      { label: "Toilet fixture replacement", value: "Varies by fixture model and labor" }
    ],
    faqs: [
      {
        question: "Why is water leaking around the base of my toilet?",
        answer:
          "A leak at the base usually indicates a failed wax ring seal or a cracked toilet flange, requiring the toilet to be lifted, inspected, and resealed."
      },
      {
        question: "Why does my toilet keep running continuously?",
        answer:
          "Continuous running is typically caused by a faulty flapper, improper float height, or a malfunctioning fill valve that wastes significant water."
      }
    ],
    overview:
      "Toilet repair addresses running water, clogs, flush failures, and base leaks to restore proper bathroom sanitation and prevent flooring damage."
  },

  "faucet-repair": {
    heroBadge: "Faucet repair information",
    intro: [
      "A dripping or leaking faucet wastes gallons of water every day and can lead to water stains, cabinet damage, and elevated utility bills.",
      "Whether in the kitchen, bathroom, or utility room, faucet problems often stem from worn cartridges, degraded O-rings, mineral buildup, or loose supply line fittings.",
      "PipeResque helps homeowners connect with licensed plumbing professionals who can rebuild fixture valves or install modern, efficient replacements."
    ],
    warningSigns: [
      "Constant dripping from the spout after the handle is turned off.",
      "Water leaking around the base of the faucet or handle onto the countertop.",
      "Low water pressure specifically from one faucet.",
      "Squeaking, grinding, or stiff handles when turning water on or off.",
      "Moisture or water droplets inside the under-sink vanity cabinet."
    ],
    repairProcess: [
      "Shut off under-sink angle stop supply valves.",
      "Disassemble faucet handle and remove stem cartridge or ball assembly.",
      "Inspect valve seat, springs, and O-ring gaskets for wear.",
      "Replace cartridge or worn internal seals with manufacturer-matching parts.",
      "Reassemble, restore water pressure, and check for leaks under pressure."
    ],
    pricing: [
      { label: "Faucet inspection & diagnosis", value: "Determined directly by provider" },
      { label: "Cartridge or seal replacement", value: "Varies by faucet brand and model" },
      { label: "Under-sink supply line repair", value: "Varies by valve access" },
      { label: "New faucet installation", value: "Varies by fixture style and complexity" }
    ],
    faqs: [
      {
        question: "Should I repair or replace a leaking faucet?",
        answer:
          "If the fixture is of good quality and parts are readily available, a cartridge replacement is cost-effective. Older or heavily corroded faucets are often better replaced."
      },
      {
        question: "What causes low water pressure at just one faucet?",
        answer:
          "A clogged aerator screen due to mineral sediment is the most common cause, followed by a partially blocked cartridge or pinched supply hose."
      }
    ],
    overview:
      "Faucet repair fixes dripping fixtures, faulty cartridges, handle leaks, and under-sink connection issues to eliminate water waste."
  },

  "commercial-plumbing": {
    heroBadge: "Commercial plumbing information",
    intro: [
      "Commercial plumbing systems handle much higher usage volumes and operate under strict municipal building codes and sanitation standards.",
      "Businesses, restaurants, offices, retail stores, and commercial facilities in Greater Houston require prompt diagnostic and repair solutions to prevent operational downtime.",
      "PipeResque connects commercial property managers and business owners with independent plumbing professionals equipped for high-capacity systems."
    ],
    warningSigns: [
      "Multiple commercial restroom fixtures backing up simultaneously.",
      "Persistent foul sewer odors in public or employee areas.",
      "Commercial water heater failure disrupting business operations.",
      "Visible leaks in commercial riser piping or utility rooms.",
      "Grease trap overflow or slow-draining kitchen lines."
    ],
    repairProcess: [
      "Evaluate commercial blueprints and isolate affected branch lines.",
      "Deploy commercial diagnostic tools such as high-resolution sewer cameras.",
      "Perform high-capacity hydro jetting, pipe relining, or fixture repair.",
      "Ensure compliance with Texas plumbing codes and local municipal regulations.",
      "Verify system functionality to minimize business disruption."
    ],
    pricing: [
      { label: "Commercial system evaluation", value: "Determined directly by provider" },
      { label: "High-capacity hydro jetting", value: "Varies by line length and access" },
      { label: "Commercial water heater service", value: "Varies by unit size and system" },
      { label: "Facility maintenance & repair", value: "Custom quote from provider" }
    ],
    faqs: [
      {
        question: "Can commercial plumbing inquiries be made outside standard business hours?",
        answer:
          "Yes. Inquiries can be submitted anytime via phone to connect with independent providers who service commercial facilities."
      },
      {
        question: "What types of commercial properties can receive assistance?",
        answer:
          "Independent contractors handle restaurants, retail storefronts, office buildings, warehouses, multi-family units, and medical facilities."
      }
    ],
    overview:
      "Commercial plumbing covers high-capacity drainage, grease interceptors, commercial water heating, backflow systems, and code-compliant repairs."
  },

  "residential-plumbing": {
    heroBadge: "Residential plumbing information",
    intro: [
      "Residential plumbing systems keep clean water flowing into your home and wastewater safely draining away. When components fail, swift attention protects your home's foundation and walls.",
      "From bathroom fixture upgrades to whole-home repiping and valve repairs, residential plumbing encompasses all domestic supply, drainage, and venting systems.",
      "PipeResque connects Houston homeowners with independent licensed plumbing providers for routine repairs, diagnostic evaluations, and urgent repairs."
    ],
    warningSigns: [
      "Discolored water coming from household faucets.",
      "Gurgling sounds in walls or fixtures when draining.",
      "Damp spots on carpets, drywall, or near baseboards.",
      "Sudden spikes in monthly municipal water bills.",
      "Aging galvanized or deteriorating copper supply lines."
    ],
    repairProcess: [
      "Thorough residential plumbing inspection of supply lines, drains, and fixtures.",
      "Identification of root cause, whether localized wear or system-wide deterioration.",
      "Discussion of repair versus replacement options with transparent pricing.",
      "Quality execution of plumbing repair using durable, code-approved materials.",
      "Final pressure test and water flow verification."
    ],
    pricing: [
      { label: "In-home plumbing diagnosis", value: "Determined directly by provider" },
      { label: "General fixture & pipe repairs", value: "Varies by scope and materials" },
      { label: "Pressure regulator repair", value: "Varies by valve location" },
      { label: "Whole-home inspection", value: "Provided directly by contractor" }
    ],
    faqs: [
      {
        question: "What are the most common residential plumbing issues in Houston?",
        answer:
          "Houston's shifting clay soils and hard water often contribute to slab leaks, pipe corrosion, clogged drains, and water heater sediment buildup."
      },
      {
        question: "How do I choose between pipe repair and whole-house repiping?",
        answer:
          "Isolated leaks in newer pipes warrant simple repairs. Multiple leaks or deteriorating galvanized/polybutylene pipes are generally best addressed with PEX repiping."
      }
    ],
    overview:
      "Residential plumbing services cover home water supply, drainage, fixtures, valves, and water heaters throughout the Houston metropolitan area."
  },
};
const indexableCoreServices = new Set([
  "emergency-plumbing",
  "sewer-line-repair",
  "drain-cleaning",
  "leak-detection",
  "water-heater-repair",
  "pipe-repair",
]);

const relatedGuidesByService: Record<
  string,
  { title: string; href: string; summary: string }[]
> = {
  "sewer-line-repair": [
    {
      title: "Sewer Line Repair Guide for Houston Homeowners",
      href: "/blog/sewer-line-repair-houston-tx",
      summary: "Clay soil shifting, tree roots, trenchless relining, and camera inspections.",
    },
    {
      title: "Hydro-Jetting Sewer Lines in Houston",
      href: "/blog/hydro-jetting-sewer-lines-houston",
      summary: "When pressurized water scouring clears grease and root scale.",
    },
    {
      title: "Cast Iron Sewer Pipe Replacement in Houston",
      href: "/blog/cast-iron-sewer-pipe-replacement-houston",
      summary: "Warning signs and replacement methods for pre-1975 Houston homes.",
    },
    {
      title: "Sewer Camera Inspection Before Buying or Repairing",
      href: "/blog/sewer-camera-inspection-houston",
      summary: "Pinpointing pipe bellies, cracks, and offsets without guesswork.",
    },
  ],
  "drain-cleaning": [
    {
      title: "Drain Cleaning Guide for Houston Homes",
      href: "/blog/drain-cleaning-houston-tx",
      summary: "Distinguishing fixture clogs from main sewer lateral blockages.",
    },
    {
      title: "Hydro-Jetting Sewer Lines in Houston",
      href: "/blog/hydro-jetting-sewer-lines-houston",
      summary: "How 3,000–4,000 PSI jetting compares to mechanical cable snaking.",
    },
    {
      title: "Why Chemical Drain Cleaners Damage Pipes",
      href: "/blog/chemical-drain-cleaner-pipe-damage-houston",
      summary: "Risks of caustic drain openers on cast iron, PVC, and metal traps.",
    },
    {
      title: "Kitchen Double-Basin & Main Floor Drain Backups",
      href: "/blog/kitchen-sink-double-basin-backup-houston",
      summary: "Troubleshooting shared branch backups and cleanout access.",
    },
  ],
  "leak-detection": [
    {
      title: "Hidden Leak Detection in Houston, TX",
      href: "/blog/leak-detection-houston-tx",
      summary: "Acoustic sensors, thermal imaging, and isolation pressure testing.",
    },
    {
      title: "Slab Leak Repair & Rerouting Options",
      href: "/blog/slab-leak-repair-houston-tx",
      summary: "Handling under-slab copper leaks without unnecessary jackhammering.",
    },
    {
      title: "High Water Bill? Check for Hidden Leaks",
      href: "/blog/high-water-bill-hidden-leak-houston",
      summary: "Simple meter-dial checks to confirm silent water loss.",
    },
    {
      title: "Hot Spots on Slab Floors Explained",
      href: "/blog/hot-spots-floor-slab-leak-houston",
      summary: "Why warm tile or wood flooring often points to a hot-water slab leak.",
    },
  ],
  "water-heater-repair": [
    {
      title: "Water Heater Repair & Replacement in Houston",
      href: "/blog/water-heater-repair-houston-tx",
      summary: "Diagnosing thermostats, heating elements, gas pilots, and tank leaks.",
    },
    {
      title: "Tankless Water Heater Repair & Descaling",
      href: "/blog/tankless-water-heater-repair-houston",
      summary: "Addressing Houston mineral scale and ignition error codes.",
    },
    {
      title: "Attic Water Heater Texas Code Requirements",
      href: "/blog/attic-water-heater-code-requirements-houston",
      summary: "Drain pans, T&P relief discharge lines, and thermal expansion tanks.",
    },
    {
      title: "Why a Water Heater Leaks From the Bottom",
      href: "/blog/leaking-water-heater-bottom-houston",
      summary: "Separating drain-valve drips from internal tank shell failure.",
    },
  ],
  "pipe-repair": [
    {
      title: "Burst Pipe Repair in Houston, TX",
      href: "/blog/burst-pipe-repair-houston-tx",
      summary: "Immediate shutoff steps and sectional piping repair after freezes.",
    },
    {
      title: "PEX vs. Copper Repiping for Houston Homes",
      href: "/blog/pex-vs-copper-repipe-houston",
      summary: "Comparing freeze resilience, cost factors, and water chemistry.",
    },
    {
      title: "Main Water Shutoff Valve Replacement",
      href: "/blog/main-water-shutoff-valve-replacement-houston",
      summary: "Upgrading seized gate valves to quarter-turn ball valves.",
    },
    {
      title: "High Water Pressure & PRV Damage Prevention",
      href: "/blog/high-water-pressure-plumbing-damage-houston",
      summary: "Protecting supply lines and fixtures above 80 PSI.",
    },
  ],
  "toilet-repair": [
    {
      title: "Recurrent Toilet Clogging & Rebuild Guide",
      href: "/blog/recurrent-toilet-clogging-rebuild-houston",
      summary: "Flapper seals, wax rings, closet augers, and venting checks.",
    },
    {
      title: "Shower & Bathtub Drain Clogs",
      href: "/blog/bathroom-shower-bathtub-drain-clog-houston",
      summary: "When bathroom gurgling points to a shared branch line restriction.",
    },
  ],
  "faucet-repair": [
    {
      title: "High Water Pressure Plumbing Stress",
      href: "/blog/high-water-pressure-plumbing-damage-houston",
      summary: "How excessive supply pressure wears out cartridges and supply lines.",
    },
    {
      title: "Outdoor Hose Bibb Freeze Burst Prevention",
      href: "/blog/outdoor-hose-bibb-freeze-burst-houston",
      summary: "Replacing frost-damaged sillcocks and exterior spigots.",
    },
  ],
  "commercial-plumbing": [
    {
      title: "Commercial Grease Trap Backup Recovery",
      href: "/blog/commercial-grease-trap-backup-houston",
      summary: "Preventing kitchen downtime and FOG line blockages.",
    },
    {
      title: "Commercial Backflow Preventer Testing",
      href: "/blog/commercial-backflow-preventer-testing-houston",
      summary: "Annual certification and compliance for Greater Houston properties.",
    },
  ],
  "residential-plumbing": [
    {
      title: "Whole-Home Repiping in Houston, TX",
      href: "/blog/repipe-services-houston-tx",
      summary: "Replacing aging galvanized or pinhole-prone copper supply piping.",
    },
    {
      title: "How to Shut Off Your Main Water Valve",
      href: "/blog/how-to-shut-off-main-water-houston",
      summary: "Step-by-step property protection before a plumber arrives.",
    },
  ],
};

export const dynamicParams = false;

export async function generateStaticParams() {
  return services.map((service) => ({
    slug: service.slug,
  }));
}

export async function generateMetadata({
  params,
}: Props): Promise<Metadata> {
  const { slug } = await params;

  const service = services.find((item) => item.slug === slug);

  if (!service) {
    notFound();
  }

  const content = serviceContent[service.slug];
  const baseTitle = (
    service.seoTitle || `${service.title} in Houston, TX`
  ).replace(/\s*\|\s*Pipe[rR]esque$/i, "");

  return {
    title: baseTitle,
    description:
      service.metaDescription ||
      content?.overview ||
      `${service.title} in Houston, Texas: Understand common symptoms, repair options, and connect with independent local plumbing providers.`,
    alternates: {
      canonical: `https://www.piperesque.com/services/${service.slug}`,
    },
    openGraph: {
      title: `${baseTitle} | PipeResque`,
      description:
        service.metaDescription ||
        content?.overview ||
        `${service.title} in Houston, Texas: Understand common symptoms, repair options, and connect with independent local plumbing providers.`,
      url: `https://www.piperesque.com/services/${service.slug}`,
      siteName: siteConfig.company,
      type: "website",
    },
  };
}

export default async function ServicePage({ params }: Props) {
  const { slug } = await params;

  const service = services.find((item) => item.slug === slug);

  if (!service) {
    notFound();
  }

  const content = serviceContent[service.slug] ?? {
    heroBadge: `${service.shortTitle} information`,
    intro: [service.description],
    warningSigns: [
      "Water pressure irregularities or visible leaks",
      "Unusual sounds or moisture near fixtures",
      "Slow drainage or system malfunction"
    ],
    repairProcess: [
      "Contact an independent plumbing professional",
      "Technician inspects the affected plumbing system",
      "Transparent diagnosis and options are provided",
      "Repairs are completed and thoroughly tested"
    ],
    pricing: [
      { label: "Inspection & Diagnosis", value: "Determined directly by provider" },
      { label: "Repair Work", value: "Varies by scope and materials" }
    ],
    faqs: [
      {
        question: `How are ${service.shortTitle.toLowerCase()} costs determined?`,
        answer: "Costs are determined directly by the independent contractor based on parts, labor, and fixture accessibility."
      }
    ],
    overview: service.description
  };

  const faqItems = content.faqs;

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: `${service.shortTitle} Referral`,
    serviceType: service.shortTitle,
    description: content.overview,
    url: `https://www.piperesque.com/services/${service.slug}`,
    areaServed: {
      "@type": "City",
      name: "Houston",
      addressRegion: "TX",
      addressCountry: "US",
    },
    broker: {
      "@type": "Organization",
      name: siteConfig.company,
      url: "https://www.piperesque.com",
    },
    provider: {
      "@type": "Organization",
      name: "Independent Licensed Houston Plumbing Contractors (via PipeResque)",
    },
  };

  return (
    <main className="overflow-x-hidden bg-white">
      <BreadcrumbSchema
        items={[
          {
            name: "Home",
            url: "https://www.piperesque.com",
          },
          {
            name: "Services",
            url: "https://www.piperesque.com/services",
          },
          {
            name: service.shortTitle,
            url: `https://www.piperesque.com/services/${service.slug}`,
          },
        ]}
      />

      <JsonLd schema={serviceSchema} />

      <FAQSchema faqs={faqItems} />

      <Navbar />

      <section className="relative overflow-hidden bg-blue-950 py-28 text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-950 via-blue-900 to-sky-900" />

        <div className="container-custom relative z-10">
          <div className="max-w-5xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-bold uppercase tracking-[0.15em] text-blue-100">
              <Wrench size={15} />
              {content.heroBadge}
            </div>

            <h1 className="mt-6 text-4xl font-black leading-tight sm:text-5xl md:text-6xl">
              {service.title} in Houston, TX
            </h1>

            <p className="mt-6 max-w-3xl text-xl leading-9 text-blue-100">
              {content.overview}
            </p>

            <div className="mt-8 flex flex-wrap gap-4">
              <a
                href="tel:+18775873986"
                data-event="phone_click_service"
                aria-label={`Call PipeResque for ${service.shortTitle} assistance at (877) 587-3986`}
                className="inline-flex items-center gap-2 rounded-xl bg-amber-500 px-8 py-4 font-black text-slate-950 transition hover:bg-amber-400 shadow-lg shadow-amber-500/20 active:scale-[0.98]"
              >
                <Phone size={19} />
                Call (877) 587-3986
              </a>

              <Link
                href="#request-referral"
                className="inline-flex items-center gap-2 rounded-xl border border-white/30 bg-white/10 px-7 py-4 font-bold text-white transition hover:bg-white hover:text-blue-950"
              >
                Request Callback
              </Link>

              <Link
                href="/service-areas"
                className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 px-6 py-4 font-semibold text-blue-100 transition hover:bg-white/10 hover:text-white"
              >
                <MapPin size={17} />
                Service Areas
              </Link>
            </div>

            {/* Transparent Referral Platform Notice */}
            <div className="mt-8 rounded-2xl border border-blue-400/30 bg-blue-900/60 p-4 text-xs leading-relaxed text-blue-100 backdrop-blur-sm max-w-3xl">
              <span className="font-bold text-amber-300">Referral Platform Notice: </span>
              PipeResque is an informational plumbing referral platform connecting Greater Houston homeowners with independent licensed plumbing contractors. PipeResque does not directly perform physical plumbing work. Independent service providers determine their own pricing, availability, and warranty terms.
            </div>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container-custom">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-4xl font-black text-slate-900">
              About {service.shortTitle}
            </h2>

            {content.intro.map((paragraph) => (
              <p
                key={paragraph}
                className="mt-6 text-lg leading-9 text-slate-600"
              >
                {paragraph}
              </p>
            ))}

            {service.slug === "drain-cleaning" && (
              <div className="mt-10 rounded-2xl border border-blue-200 bg-blue-50/70 p-6 md:p-8">
                <h3 className="text-2xl font-black text-slate-900">
                  Hydro-Jetting vs. Mechanical Snaking in Houston
                </h3>
                <p className="mt-3 leading-7 text-slate-700">
                  Standard mechanical cable snaking punches a temporary opening through localized hair or soap clogs. When kitchen grease buildup, scale, or early tree roots coat an entire sewer lateral, independent contractors often evaluate high-pressure{" "}
                  <Link
                    href="/blog/hydro-jetting-sewer-lines-houston"
                    className="font-semibold text-blue-700 underline underline-offset-4 hover:text-blue-900"
                  >
                    hydro-jetting in Houston
                  </Link>{" "}
                  after a camera check confirms the pipe wall is structurally intact.
                </p>
              </div>
            )}

            {service.slug === "sewer-line-repair" && (
              <div className="mt-10 rounded-2xl border border-amber-200 bg-amber-50/80 p-6 md:p-8">
                <h3 className="text-2xl font-black text-slate-900">
                  Emergency Sewer Backup: Immediate Safety &amp; Shutoff Checklist
                </h3>
                <ul className="mt-4 space-y-2 text-slate-700">
                  <li>• Pause washing machines, dishwashers, and showers immediately so wastewater cannot rise higher inside lowest-level tubs.</li>
                  <li>• Keep children and pets away from any backed-up floor drain or toilet overflow.</li>
                  <li>• Do not pour caustic chemical drain openers into standing sewage, as trapped chemicals create splash hazards for technicians.</li>
                  <li>• Locate your outdoor ground-level sewer cleanout cap if safe to inspect, or read our{" "}
                    <Link
                      href="/blog/how-to-shut-off-main-water-houston"
                      className="font-semibold text-blue-700 underline underline-offset-4 hover:text-blue-900"
                    >
                      main water shutoff guide
                    </Link>{" "}
                    if fresh water continues supplying overflowing fixtures.
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-24">
        <div className="container-custom">
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-2 text-sm font-bold text-amber-800">
                <AlertTriangle size={16} />
                Warning signs
              </div>

              <h2 className="mt-5 text-4xl font-black text-slate-900">
                Signs you may need {service.shortTitle.toLowerCase()}
              </h2>

              <div className="mt-8 space-y-4">
                {content.warningSigns.map((sign) => (
                  <div
                    key={sign}
                    className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-5"
                  >
                    <ShieldCheck
                      size={22}
                      className="mt-1 shrink-0 text-blue-600"
                    />

                    <p className="leading-7 text-slate-700">{sign}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-blue-100 px-4 py-2 text-sm font-bold text-blue-800">
                <Wrench size={16} />
                Service process
              </div>

              <h2 className="mt-5 text-4xl font-black text-slate-900">
                What the service may involve
              </h2>

              <div className="mt-8 space-y-4">
                {content.repairProcess.map((step, index) => (
                  <div
                    key={step}
                    className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-5"
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-600 text-sm font-black text-white">
                      {index + 1}
                    </div>

                    <p className="leading-7 text-slate-700">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mid-Page Conversion Action */}
      <section className="bg-slate-900 py-14 text-white">
        <div className="container-custom">
          <div className="mx-auto max-w-4xl rounded-2xl border border-slate-800 bg-slate-950 p-8 md:p-10 text-center">
            <span className="inline-flex rounded-full bg-amber-500/10 border border-amber-500/20 px-3.5 py-1 text-xs font-bold uppercase tracking-wider text-amber-400">
              Need Assistance Now?
            </span>
            <h3 className="mt-4 text-2xl md:text-3xl font-black text-white">
              Dealing With a {service.shortTitle} Problem in Houston?
            </h3>
            <p className="mt-3 text-base text-slate-300 max-w-2xl mx-auto">
              Don&apos;t let plumbing damage escalate. Call our referral line now to discuss your situation and connect with an independent local plumbing provider.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="tel:+18775873986"
                data-event="phone_click_service"
                aria-label={`Call PipeResque for ${service.shortTitle} at (877) 587-3986`}
                className="inline-flex items-center gap-2.5 rounded-xl bg-amber-500 px-8 py-3.5 text-base font-black text-slate-950 transition hover:bg-amber-400 active:scale-95 shadow-md shadow-amber-500/20"
              >
                <Phone size={18} className="fill-slate-950" aria-hidden="true" />
                Call (877) 587-3986
              </a>
              <Link
                href="#request-referral"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-6 py-3.5 text-base font-semibold text-white transition hover:bg-slate-700"
              >
                Request Callback
                <ArrowRight size={17} aria-hidden="true" />
              </Link>
            </div>
            <p className="mt-4 text-xs text-slate-400">
              PipeResque is a plumbing referral platform. Services are performed by independent providers, not PipeResque.
            </p>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container-custom">
          <div className="mx-auto max-w-5xl">
            <div className="rounded-[32px] border border-blue-100 bg-blue-50 p-8 md:p-10">
              <div className="flex items-center gap-3">
                <BadgeCheck className="text-blue-700" size={24} />

                <h2 className="text-3xl font-black text-slate-900">
                  Pricing information
                </h2>
              </div>

              <p className="mt-4 max-w-3xl leading-8 text-slate-600">
                Plumbing pricing varies by provider, location, labor,
                materials, accessibility, equipment, and the complexity of
                the problem. The information below is provided for general
                context and should not be treated as a quote.
              </p>

              <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {content.pricing.map((item) => (
                  <div
                    key={item.label}
                    className="rounded-2xl border border-blue-100 bg-white p-6"
                  >
                    <p className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500">
                      {item.label}
                    </p>

                    <p className="mt-3 text-lg font-black text-blue-700">
                      {item.value}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-24">
        <div className="container-custom">
          <div className="mx-auto max-w-4xl">
            <div className="flex items-center gap-3">
              <Sparkles className="text-blue-600" size={24} />

              <h2 className="text-4xl font-black text-slate-900">
                Frequently Asked Questions
              </h2>
            </div>

            <div className="mt-10 space-y-5">
              {content.faqs.map((faq) => (
                <details
                  key={faq.question}
                  className="group rounded-2xl border border-slate-200 bg-white p-6"
                >
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-6 text-lg font-bold text-slate-900">
                    <span>{faq.question}</span>

                    <ChevronRight
                      size={20}
                      className="shrink-0 transition-transform group-open:rotate-90"
                    />
                  </summary>

                  <p className="mt-4 max-w-3xl leading-8 text-slate-600">
                    {faq.answer}
                  </p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white border-t border-slate-200">
        <div className="container-custom">
          <div className="mx-auto max-w-4xl">
            <ReferralLeadForm
              defaultService={service.shortTitle}
              heading={`Request ${service.shortTitle} Referral in Houston`}
              id="request-referral"
            />
          </div>
        </div>
      </section>

      {/* Curated Internal Guides */}
      <section className="py-16 bg-slate-50 border-t border-slate-200">
        <div className="container-custom">
          <div className="mx-auto max-w-5xl">
            <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
              <div>
                <h2 className="text-3xl font-black text-slate-900">
                  Helpful Houston {service.shortTitle} Guides
                </h2>
                <p className="mt-2 text-slate-600">
                  Review local technical resources and jump straight to the Houston neighborhood hub.
                </p>
              </div>
              <Link
                href={`/location/houston/${service.slug}`}
                className="inline-flex items-center gap-2 rounded-xl bg-blue-700 px-5 py-3 text-sm font-bold text-white transition hover:bg-blue-800 shrink-0"
              >
                Houston {service.shortTitle} Hub
                <ArrowRight size={16} />
              </Link>
            </div>

            <div className="mt-8 grid gap-4 md:grid-cols-2">
              {(relatedGuidesByService[service.slug] ?? []).map((guide) => (
                <Link
                  key={guide.href}
                  href={guide.href}
                  className="group rounded-2xl border border-slate-200 bg-white p-6 transition hover:border-blue-400 hover:shadow-sm"
                >
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-700">
                    {guide.title}
                  </h3>
                  <p className="mt-2 text-sm leading-6 text-slate-600">
                    {guide.summary}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container-custom">
          <div className="mx-auto max-w-5xl">
            <div className="rounded-[32px] border border-slate-200 bg-white p-8 shadow-sm md:p-10">
              <div className="flex items-center gap-3">
                <MapPin className="text-blue-600" size={24} />

                <h2 className="text-3xl font-black text-slate-900">
                  Explore local service areas
                </h2>
              </div>

              <p className="mt-4 max-w-3xl leading-8 text-slate-600">
                Looking for plumbing assistance in a specific Greater Houston community?
                Explore our local referral hubs below.
              </p>

              <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  "houston",
                  "katy",
                  "sugar-land",
                  "cypress",
                  "spring",
                  "pearland",
                  "pasadena",
                  "richmond",
                  "missouri-city",
                  "the-woodlands",
                ].map((city) => {
                  const targetHref =
                    city === "houston" || indexableCoreServices.has(service.slug)
                      ? `/location/${city}/${service.slug}`
                      : `/service-areas/${city}`;

                  return (
                    <Link
                      key={city}
                      href={targetHref}
                      className="group flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 font-bold text-slate-800 transition hover:border-blue-400 hover:bg-blue-50 hover:text-blue-700"
                    >
                      <span>
                        {city
                          .split("-")
                          .map(
                            (word) =>
                              word.charAt(0).toUpperCase() + word.slice(1)
                          )
                          .join(" ")}
                      </span>

                      <ArrowRight
                        size={18}
                        className="transition-transform group-hover:translate-x-1"
                      />
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      <CTA />

      <Footer />
    </main>
  );
}